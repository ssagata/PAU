package pkp_1;

public enum TrainStatus {
    DELAYED,NEW,ONTIME,FULL,CHANGED
}



/*
private enum TrainStatus {
YES{
@Override public String toString(){
return "yes";
  }
  },

  NO,
  MAYBE
}
 */