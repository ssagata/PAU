package zad1;

public interface Strategy {
    public double sort(int []tab);
}
