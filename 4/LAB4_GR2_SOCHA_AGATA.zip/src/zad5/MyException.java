package zad5;

public class MyException extends Exception{
    public MyException( ){
        System.out.println("There have to be two different numbers");
    }
}
