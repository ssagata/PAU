package kalkulator;

public interface Printable {
    void print();
}
